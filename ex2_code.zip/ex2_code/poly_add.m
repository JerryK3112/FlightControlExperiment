function result = poly_add(p1, p2)
    % 确保两个向量长度相同
    len1 = length(p1);
    len2 = length(p2);
    
    if len1 > len2
        p2 = [zeros(1, len1-len2), p2];
    elseif len2 > len1
        p1 = [zeros(1, len2-len1), p1];
    end
    
    result = p1 + p2;
end