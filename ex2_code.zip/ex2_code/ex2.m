clear all;   
clc;         
close all;    
%% 创建系统矩阵
A_lat=[-1.2370e-1 7.2557e-2  -9.8430e-1 7.4400e-2 0;
       -3.0217    -9.5080e-1 4.6280e-1  0         0;
       9.3662e-1  -1.1060e-1 -2.8020e-1 0         0;
       0          1          6.9920e-1  0         0;
       0          0          1.0024     0         0];
   
B_lat=[0          5.4984e-2;
       -9.0080e-1 9.8590e-1;
       4.0440e-2  -1.5140;
       0          0;
       0          0];
   
C_lat=eye(5,5);

D_lat=zeros(5,2);

plane=ss(A_lat,B_lat,C_lat,D_lat);

%% 飞机的长周期与短周期阻尼与自然频率
eigenvalues = eig(A_lat);
w_n=zeros(5,1);
zeta=zeros(5,1);
for i=1:length(eigenvalues)
    [w_n(i),zeta(i)]=damp(eigenvalues(i));
end
disp("系统特征根为：");
disp(eigenvalues);
disp("特征根对应的自然频率为：");
disp(w_n);
disp("特征根对应的阻尼比为：");
disp(zeta);

%% 对副翼和方向舵单位阶跃输入下的飞机自然特性进行仿真

namespace=['Δβ','Δp','Δr','ΔΦ','Δψ'];
colorspace=['#FA2581','#25D8FA','#FA4925','#25FAA6','#A55E50'];
% 副翼的单位阶跃
figure(1);
t_s=0:0.01:7;
t_l=0:0.1:50;
y_s=step(plane(:,1), t_s); 
y_l=step(plane(:,1), t_l); 
for i=1:5
    subplot(5,2,2*i-1);
    plot(t_s,y_s(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in short period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;

    subplot(5,2,2*i);
    plot(t_l,y_l(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in long period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;
end
sgtitle('五个飞行状态量对副翼阶跃后的响应变化', 'FontSize', 20, 'FontWeight', 'bold');

% 方向舵的单位阶跃
figure(2);
t_s=0:0.01:7;
t_l=0:0.1:50;
y_s=step(plane(:,2), t_s)*pi/180; 
y_l=step(plane(:,2), t_l)*pi/180; 
for i=1:5
    subplot(5,2,2*i-1);
    plot(t_s,y_s(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in short period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;

    subplot(5,2,2*i);
    plot(t_l,y_l(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in long period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;
end
sgtitle('五个飞行状态量对方向舵阶跃后的响应变化', 'FontSize', 20, 'FontWeight', 'bold');

% 同时单位阶跃
figure(3);
t_all=0:0.1:50;
step=[ones(1,length(t_all));ones(1,length(t_all))]';
y_all=lsim(plane,step,t_all);
for i=1:5
    subplot(5,1,i);
    plot(t_all,y_all(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;
end
sgtitle('五个飞行状态量对副翼和方向舵同时阶跃后的响应变化', 'FontSize', 20, 'FontWeight', 'bold');

%% 分析横向
% 滚转角速率关于副翼
A_dp=A_lat(2,2);
B_dp=B_lat(2,:);
C_dp=C_lat(2,2);
D_dp=D_lat(2,:);

[num_dp,den_dp]=ss2tf(A_dp,B_dp,C_dp,D_dp,1);
disp("模态简化后，俯仰角速率关于升降舵的传递函数为：")
disp(num_dp(1,:));
disp(den_dp);

%在simulink绘制了模板
D1=[0.1 1];
N2=[-0.9008];
D2=[1 0.9508];

% 先设计K_a_p，分析Δp与杆量之间的传递函数的根轨迹更为方便
% num_P=conv(N2,[1,0]);
% den_P=poly_add(N2,-conv(D1,conv(D2,[1,0])));
% aileron_P=tf(num_P,den_P);
% rltool(aileron_P)

K_a_p=0.95108;

% 再设计K_a_phi
num_2P=-N2;
den_2P=conv([1,0],poly_add(conv(D1,D2),-K_a_p*N2));
elevator_2P=tf(num_2P,den_2P);
rltool(elevator_2P)

K_a_phi=1.1268;

%% 分析航向
A_psi=A_lat([1,3,5],[1,3,5]);
B_psi=B_lat([1,3,5],:);
C_psi=C_lat([1,3,5],[1,3,5]);
D_psi=D_lat([1,3,5],:);

% 偏航角速率关于方向舵
[num_psi,den_psi]=ss2tf(A_psi,B_psi,C_psi,D_psi,2);
disp("模态简化后，偏航角速率关于方向舵的传递函数为：")
disp(num_psi(2,:));
disp(den_psi);

%在simulink绘制了模板
D1=[0.1 1];
N2=[-1.5140 -0.1358];
D2=[1 0.4039 0.9566];

% 先设计K_r_r，分析Δp与杆量之间的传递函数的根轨迹更为方便
% num_P=conv(N2,[1,0]);
% den_P=poly_add(N2,-conv(D1,conv(D2,[1,0])));
% rudder_P=tf(num_P,den_P);
% rltool(rudder_P)
% 
K_r_r=1.2559;

% 再设计K_r_psi
num_2P=-N2;
den_2P=conv([1,0],poly_add(conv(D1,D2),-K_r_r*N2));
rudder_2P=tf(num_2P,den_2P);
% rltool(rudder_2P)

% K_r_phi=1.8832;

