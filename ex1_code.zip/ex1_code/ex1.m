clear all;   
clc;         
close all;    
%% 创建系统矩阵
A_lon=[-8.0381e-3 5.0167    -1.8188e-3 -9.7974 0;
       -1.0474e-3 -5.691e-1 9.7835e-1 0       0;
       2.4132e-5  -1.2614   -8.582e-1 0       0;
       0          0         1         0       0;
       0          -131.5    0         131.5   0];
   
B_lon=[-7.9462e-1 6.9351e-2;
       -9.4485e-2 -3.6872e-5;
       -3.9970    2.2749e-3;
       0          0;
       0          0];
   
C_lon=eye(5,5);

D_lon=zeros(5,2);

plane=ss(A_lon,B_lon,C_lon,D_lon);

%% 飞机的长周期与短周期阻尼与自然频率
eigenvalues = eig(A_lon);
w_n=zeros(5,1);
zeta=zeros(5,1);
for i=1:length(eigenvalues)
    [w_n(i),zeta(i)]=damp(eigenvalues(i));
end
disp("系统特征根为：");
disp(eigenvalues);
disp("特征根对应的自然频率为：");
disp(w_n);
disp("特征根对应的阻尼比为：");
disp(zeta);

%% 对升降舵及油门单位阶跃输入下的飞机自然特性进行仿真

namespace=['ΔV','Δα','Δq','Δθ','ΔH'];
colorspace=['#FFABB5','#0FB1FF','#FF4D0F','#0FFFCB','#AA5D43'];
% 升降舵的单位阶跃
figure(1);
t_s=0:0.01:7;
t_l=0:0.1:2000;
y_s=step(plane(:,1), t_s); 
y_l=step(plane(:,1), t_l); 
for i=1:5
    subplot(5,2,2*i-1);
    plot(t_s,y_s(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in short period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;

    subplot(5,2,2*i);
    plot(t_l,y_l(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in long period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;
end
sgtitle('五个飞行状态量对升降舵阶跃后的响应变化', 'FontSize', 20, 'FontWeight', 'bold');

% 油门的单位阶跃
figure(2);
t_s=0:0.01:7;
t_l=0:0.1:2000;
y_s=step(plane(:,2), t_s)*pi/180; 
y_l=step(plane(:,2), t_l)*pi/180; 
for i=1:5
    subplot(5,2,2*i-1);
    plot(t_s,y_s(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in short period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;

    subplot(5,2,2*i);
    plot(t_l,y_l(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in long period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;
end
sgtitle('五个飞行状态量对油门阶跃后的响应变化', 'FontSize', 20, 'FontWeight', 'bold');

% 同时单位阶跃
figure(3);
t_all=0:0.1:2000;
step=[ones(1,length(t_all));ones(1,length(t_all))]';
y_all=lsim(plane,step,t_all);
for i=1:5
    subplot(5,1,i);
    plot(t_all,y_all(:,i),'Color',colorspace(7*i-6:7*i),'Linewidth',3);
    title(strcat(namespace(2*i-1:2*i)," in short period"),'Fontsize',16);
    xlabel('t(s)','Fontsize',12);
    ylabel(namespace(2*i-1:2*i),'Fontsize',12);
    grid on;
end
sgtitle('五个飞行状态量对升降舵和油门同时阶跃后的响应变化', 'FontSize', 20, 'FontWeight', 'bold');

%% 分析短周期
A_sp=A_lon(2:3,2:3);
B_sp=B_lon(2:3,:);
C_sp=C_lon(2:3,2:3);
D_sp=D_lon(2:3,:);

%俯仰角速率关于升降舵
[num_sp,den_sp]=ss2tf(A_sp,B_sp,C_sp,D_sp,1);
disp("短周期简化后，俯仰角速率关于升降舵的传递函数为：")
disp(num_sp(2,:));
disp(den_sp);

%在simulink绘制了模板
D1=[0.1 1];
N2=[-3.9970 -2.1555];
D2=[1 1.4723 1.7225];

%先设计K_e_q，分析Δq与杆量之间的传递函数的根轨迹更为方便
% num_P=conv(N2,[1,0]);
% den_P=poly_add(N2,-conv(D1,conv(D2,[1,0])));
% elevator_P=tf(num_P,den_P);
% rltool(elevator_P)

K_e_q=0.68022;

%再设计K_e_theta
num_2P=-N2;
den_2P=conv([1,0],poly_add(conv(D1,D2),-K_e_q*N2));
elevator_2P=tf(num_2P,den_2P);
rltool(elevator_2P)

K_e_theta=1.8832;

%% 分析长周期
A_ph=A_lon([1,4],[1,4]);
B_ph=B_lon([1,4],:);
C_ph=C_lon([1,4],[1,4]);
D_ph=D_lon([1,4],:);

% 速度关于油门
[num_ph,den_ph]=ss2tf(A_ph,B_ph,C_ph,D_ph,2);
disp("长周期简化后，速度关于油门的传递函数为：")
disp(num_ph(1,:));
disp(den_ph);

%在simulink绘制了模板
D1=[0.1 1];
N2=[0.0694];
D2=[1 0.008];

% 设计PID控制器
num_O=N2;
den_O=conv(D1,D2);
thrust_O=tf(num_O,den_O);
pidtool(thrust_O);
