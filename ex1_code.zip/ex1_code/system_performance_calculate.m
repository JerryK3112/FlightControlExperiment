function [ess,ts,sigma,t,output] = system_performance_calculate(system)
    t=0:0.1:100;
    output=step(system,t);
    
    ess=output(end)-1;

    if ess>0.05 || ess<-0.05
        ts=100;
    else
        for ts=1:length(output)
            if max(output(ts:end))<1.05 && min(output(ts:end))>0.95
                ts=ts*0.01;
                break
            end
        end
    end

    output_d=[];
    for i=2:length(output)
        output_d(end+1)=(output(i)-output(i-1))/0.1;
    end

    for i=2:length(output_d)
        if output_d(i-1)*output_d(i)<0
            if output(i)>1
                sigma=output(i)-1;
            else
                sigma=0;
            end
        else
            sigma=0;
        end
    end

end
