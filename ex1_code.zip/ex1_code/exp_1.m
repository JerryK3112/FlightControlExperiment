%ss创建状态空间模型
%%sys = ss(A,B,C,D);
%initial求零输入响应
%initial(sys,x0,Tfinal);//Tfinal连续到什么时候结束
% //小扰动方程单位用的弧度，若输入的是度，则要进行单位转换。
%[y,t,x] = initial(xyx,x0);t是时间。把值输入到变量里，可以用变量画图。上面的应该可以直接画图。
%step阶跃响应
%stsp(sys)
%[y,t] = step(sys)等画图方法
%eig特征根
%poly特征多项式
%p = poly(r);
%p = poly(A);//求特征多项式系数
%r = roots(p);//求根


%syms s
A = [-8.0381*10^-3,5.0167,-1.8188*10^-3,-9.7974,0;-1.0474*10^-3,-5.691*10^-1,9.7835*10^-1,0,0;2.4132*10^-5,-1.2614,-8.582*10^-1,0,0;0,0,1,0,0;0,-131.5,0,131.5,0];
B = [-7.9462*10^-1,6.9351*10^-2;-9.4485*10^-2,-3.6872*10^-5;-3.997,2.279*10^-3;0,0;0,0];
C = [1,0,0,0,0;0,1,0,0,0;0,0,1,0,0;0,0,0,1,0;0,0,0,0,1];
D = [0,0;0,0;0,0;0,0;0,0];
sys_airplane = ss(A,B,C,D);
A1 = [-5.691*10^-1,9.7835*10^-1,0;-1.2614,-8.582*10^-1,0;0,1,0];
B1 = [-9.4485*10^-2;-3.997;0];
C1 = [1,0,0;0,1,0;0,0,1];
D1 = [0;0;0];
[num,den] = ss2tf(A1,B1,C1,D1)
G = tf(num(2,:),den);%开环传递函数
PHi = tf(G,1+G)%闭环传递函数
s = tf('s');
plant = (-3.997*s-2.156)/(s^2+1.427*s+1.722)
%K = 350;
%sys_cl = feedback(G,1)
%step(sys_cl);


% 求雅克比矩阵的特征值
[V,D] = eig(A1);%V是特征向量矩阵，D是对角矩阵，对角线上是特征值
r = diag(D);  % 提取特征值
%计算周期
T_short = 2*pi/abs(imag(r(1)));
T_long = 2*pi/abs(imag(r(3)));

% 分析特征值以确定短周期和长周期模态
% 短周期模态通常对应于具有较大实部的复共轭特征值
% 长周期模态通常对应于具有较小实部的复共轭特征值
% 计算阻尼和自然频率
damping_ratios = -real(r) ./ abs(r);
natural_frequencies = abs(r);

% 输出结果
disp('Eigenvalues:'); disp(r);
disp('Damping Ratios:'); disp(damping_ratios);
disp('Natural Frequencies:'); disp(natural_frequencies);

%%对升降舵及油门单位阶跃输入下的飞机自然特性进行仿真
G_rudder = tf(10,[1,10]);
%将舵回路模型与飞机模型串联
sys_combined = series(G_rudder, sys_airplane);

u_step = [0.1;0.1];%单位阶跃响应

% 设置仿真时间
tspan = 0:0.01:5000; % 0 到 100 秒，步长 0.01 秒
U = [u_step(1)*ones(size(tspan)); u_step(2)*ones(size(tspan))]';
% 仿真
[y, t, x] = lsim(sys_combined, U, tspan);
% 绘制输出响应
figure;
plot(t,y(:,1),'Color', '#333333'); % deta V (m/s)
hold on;
plot(t,57.3*y(:,2),'m');% deta alpha (°)
hold on;
plot(t,57.3*y(:,3),'b');% deta q (°)
hold on;
plot(t,57.3*y(:,4),'r');% deta theta (°)
hold on;
plot(t,y(:,5),'g');% deta H (m)
%title('Zero-input Response');
legend('△V','△alpha','△q','△theta','△H');
ylabel('m/s   °   °/s');
xlabel('Time (s)');
grid on;



%figure;
%subplot(3, 1, 1);
%plot(t, y);
%title('Output Response');
%xlabel('Time (s)');
%ylabel('Output');


